package com.bookies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookiesBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
