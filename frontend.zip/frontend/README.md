# Welcome to Bookies
Bookies is a Library Management System designed to manage book inventory, borrowing, and user requests efficiently. It provides separate functionalities for Admins and Users, allowing secure login, book tracking, request handling, and overdue management.

